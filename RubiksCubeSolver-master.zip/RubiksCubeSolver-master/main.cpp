#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
